from twilio.rest import TwilioRestClient

def lambda_handler(event, context):

    account_sid = "AC4d2fcda9233f32e0455c24f2844643c4" # Your Account SID from www.twilio.com/console
    auth_token  = "0f8af9b2633995fb264fe06100b63e7c"  # Your Auth Token from www.twilio.com/console

    client = TwilioRestClient(account_sid, auth_token)

    message = client.messages.create(body="Hello from Ruchir",
    to="+15617620868",    # Replace with your phone number
    from_="+15005550006") # Replace with your Twilio number
    
    print(message.sid)