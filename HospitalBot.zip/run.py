from flask import Flask, request, redirect,session
import twilio.twiml


callers = {
    "+18572141901": "Admin",
    "+18573897908":"Admin2",
}
#SECRET_KEY = 'a secret key'

#counter=0

app = Flask(__name__)

@app.route("/", methods=['GET', 'POST'])
def hello_monkey():
    """Respond to incoming calls with a simple text message."""
    counter = session.get('counter', 0)
    counter += 1
    session['counter'] = counter
    resp = twilio.twiml.Response()
    from_number = request.values.get('From', None)
    if from_number in callers:

    	print('Response : '+request.values.get('Body', None))
    	print('Counter : '+ str(counter))

        if request.values.get('Body', None)=='Y' and counter==1:
        	resp.message("Ok, We will require an additional 3 doctors ad 3 nurses. Should I start Sending invites based on priority?(Y/N)")
        	return str(resp)
        elif request.values.get('Body', None)=='Y' and counter==2:
        	resp.message("Thanks!! I am sending emails to staff")
        	sendToStaff()
        	return str(resp)
        else:
        	resp.message("Thanks!! Not sending emails")
        	return str(resp)

def sendToStaff():
	#TODO:Send an msgs to Staff
	print('Invoke Lambda')
	session.clear()

if __name__ == "__main__":
	app.secret_key = 'A0Zr98j/3yX R~XHH!jmN]LWXRT'
	app.run(debug=True)
	session.clear()