from __future__ import print_function

import json
import boto3

print('Loading function')

client = boto3.client('lambda')

payload=b"""{
  
}"""



def lambda_handler(event, context):
    
    try:
        client.invoke_async(
            FunctionName='HospitalBot',
            InvokeArgs=payload
        )

    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise e
