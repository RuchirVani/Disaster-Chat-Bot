from chalice import Chalice,Response
import twilio.twiml
from twilio.rest import TwilioRestClient
import csv
import os
import httplib2
import argparse
from apiclient import discovery
from oauth2client import client
from oauth2client import tools
from oauth2client.file import Storage
from icalendar import Calendar, Event,vCalAddress,vText,vDatetime
import boto3
import datetime
from datetime import timedelta
import pytz
import uuid

app = Chalice(app_name='disasterBotServer')

Admin={
	"+14576546745": "Admin", # Phone number
}
fromEmailAddress='whatewrv@gmail.com' # 



@app.route('/', methods=['POST', 'GET'])
def workon_response():
	request = app.current_request
	#requestJob= Request()
	print(request.method)
	print(request.headers)
	from_number=request.query_params['From']
	print("From number"+ from_number.strip())
	print(request.query_params['Body'])
	if from_number in Admin:
		print('Its Admin')
		if request.query_params['Body']=='Y':
			print('It is Admin and Responsed Yes')
			print(sendToStaff())
			return Response(body="Started Sending Messages to Staff",
                    status_code=200,
                    headers={'Content-Type': 'text/plain'})
		else:
			return Response(body="Not sending messages",
                    status_code=200,
                    headers={'Content-Type': 'text/plain'})
	else:
		if request.query_params['Body']=='Yes':
			reponse=sendCalenderInvite(from_number)
			if reponse=='Error sending Invite':
				return Response(body="Error sending Invite to calender",
                    status_code=200,
                    headers={'Content-Type': 'text/plain'})
			else:
				return Response(body="Invite has been sent via Email",
                    status_code=200,
                    headers={'Content-Type': 'text/plain'})

		elif request.query_params['Body']=='No':
			return Response(body="Ok, Thanks.No Problem!!",
                    status_code=200,
                    headers={'Content-Type': 'text/plain'})
		else:
			return Response(body="I can't understand it!! Please say Yes or No!!",
                    status_code=200,
                    headers={'Content-Type': 'text/plain'})

def sendToStaff():
	try:

		listOfStaff=[]
		rownum = 0
		print('Sending to staff method')
		filename = os.path.join(os.path.dirname(__file__), 'chalicelib', 'Disaster_Bot2.csv')	
		print('FileName:'+ filename)
		with open(filename,'rb') as csvfile:
			reader = csv.reader(csvfile)

			for row in reader:
				if rownum ==0:
					print('header')
				else:
					listOfStaff.append(row[2])
				rownum=rownum+1

		print(listOfStaff)
		account_sid = "sldkfjvdfkdfb" # Your Account SID from www.twilio.com/console
		auth_token  = "8w90e4fhejrv09dfivo9"  # Your Auth Token from www.twilio.com/console
		#client = TwilioRestClient(account_sid, auth_token)
		counter_to_send=0
		for to_number in listOfStaff:
			client = TwilioRestClient(account_sid, auth_token,base="https://api.twilio.com:8443")
			message = client.messages.create(body='''Huricane Katrina is approching and we need to increase staff at MGH. Can you accept a shift at 8.00 AM on 3/30/2017?''',to="+1"+str(to_number),from_="+14843194502")
			counter_to_send=counter_to_send+1
		return 'Done'
	except Exception as e:
		print(e)
		print('Error sending SMS to staff')
		raise e

# Google Calender
# Didnt work out becasue it uses OATH authetication which requires response to store on local but Lambda doesnt have local 
'''
def sendCalenderIvite():
	try:
		flags = tools.argparser.parse_args(args=[])
		SCOPES = 'https://www.googleapis.com/auth/calendar'
		CLIENT_SECRET_FILE = os.path.join(os.path.dirname(__file__), 'chalicelib', 'client_secret.json')
		APPLICATION_NAME = 'Google Calnder APP'

		credential_dir = os.path.join(os.path.dirname(__file__), '.credentials')
		if not os.path.exists(credential_dir):
			os.makedirs(credential_dir)
			credential_path = os.path.join(credential_dir,'calendar-python-quickstart.json')

		store = Storage(credential_path)
		credentials = store.get()
		if not credentials or credentials.invalid:
			flow = client.flow_from_clientsecrets(CLIENT_SECRET_FILE, SCOPES)
			flow.user_agent = APPLICATION_NAME
			if flags:
				credentials = tools.run_flow(flow, store, flags)
			else:
				credentials = tools.run(flow, store)

		http = credentials.authorize(httplib2.Http())
		service = discovery.build('calendar', 'v3', http=http)
		event = {
		'summary': 'Google I/O 2015',
	    'location': '800 Howard St., San Francisco, CA 94103',
	    'description': 'A chance to hear more about Google\'s developer products.',
	    'start': {
	    	'dateTime': '2017-06-28T09:00:00-07:00',
	    	'timeZone': 'America/Los_Angeles',
	  	},
	  	'end': {
	    	'dateTime': '2017-06-28T17:00:00-07:00',
	    	'timeZone': 'America/Los_Angeles',
	  	}
		}
		event = service.events().insert(calendarId='primary', body=event).execute()
		return 'Sent'
	except Exception as e:
		print(e)
		print('Error adding to calender!!')
		raise e
'''

def sendCalenderInvite(from_number):
	try:
		#get email address
		filename = os.path.join(os.path.dirname(__file__), 'chalicelib', 'Disaster_Bot2.csv')	
		print('FileName:'+ filename)
		with open(filename,'rb') as csvfile:
			reader = csv.reader(csvfile)

			for row in reader:
				if '+1'+row[2]==from_number:
					ToEmailAddress=row[3]
					break
				else:
					ToEmailAddress=None





		cal = Calendar()
		cal.add('prodid', '-//Google Inc//Google Calendar 70.9054//EN')
		cal.add('version', '2.0')
		cal.add('CALSCALE','GREGORIAN')
		cal.add('method','REQUEST')


		event = Event()
		cuurentYear=datetime.datetime.now().year
		currentMonth=datetime.datetime.now().month
		currentDate=(datetime.datetime.now()+timedelta(days=3)).day
		event['summary']='Huricane Katrina Disaster relief'

		event['dtstart']=vDatetime(datetime.datetime(cuurentYear,currentMonth,currentDate,8,0,0)).to_ical()
		event['dtend']=vDatetime(datetime.datetime(cuurentYear,currentMonth,currentDate,9,0,0)).to_ical()
		#event['dtstart']=datetime.datetime.strptime(datetime.datetime(cuurentYear,currentMonth,currentDate,8,0,0,tzinfo=pytz.utc),"%Y-%m-%d %H:%M:%SZ") 
		#event['dtend']='20170425T220000Z'
		#event['dtstart'] = datetime(cuurentYear,currentMonth,currentDate,8,0,0)
		#event['dtend']=datetime(cuurentYear,currentMonth,currentDate,16,0,0)
		event['dtstamp']=vDatetime(datetime.datetime(cuurentYear,currentMonth,currentDate,9,0,0)).to_ical()
		organizer=vCalAddress('MAILTO:'+fromEmailAddress)
		organizer.params['role'] = vText('CHAIR')
		event['organizer']=organizer
		attendee = vCalAddress('MAILTO:'+ToEmailAddress)
		attendee.params['ROLE'] = vText('REQ-PARTICIPANT')
		event['attendee']=attendee
		event['uid']=str(uuid.uuid1())
		event['transp']='OPAQUE'
		#event['dtstart'] = '20170425T080000'
		#event['dtend'] = '20170425T100000'
		cal.add_component(event)
		calendarData=cal.to_ical()
		client = boto3.client('ses',aws_access_key_id='98324tyhuejfg0',
	    aws_secret_access_key='-09to;g0bvm 003-4',region_name='us-east-1')


		#Send raw Email
		if ToEmailAddress is not None:
			print('EmailAddress is not null :'+ ToEmailAddress)
			print(type(ToEmailAddress))
			response = client.send_raw_email(
		    Destinations=[
		    ],
		    RawMessage={
		        'Data': '''From:'''+ str(fromEmailAddress) +'''\nTo:'''+str(ToEmailAddress)+'''\nSubject: Calender Invite (contains an attachment)\nMIME-Version: 1.0\nContent-type: Multipart/Mixed; boundary="NextPart"\n\n
		    --NextPart\n
		    Content-Type: text/plain\n
		    \nThis email has invite.\n
		    \n--NextPart
		    \nContent-Type: text/calendar;
		    \nContent-Disposition: attachment;filename="invite.ics"\n\n'''+str(calendarData) #+'''\n\n--NextPart--','''
		    },Source=str(fromEmailAddress),)

		print("Response from SES: "+ response['MessageId'])

	except Exception as e:
		print(e)
		print('Error sending Invite to staff number: ' + from_number)
		return 'Error sending Invite'



# The view function above will 
# whenever you make an HTTP GET request to '/'.
#
# Here are a few more examples:
#
# @app.route('/hello/{name}')
# def hello_name(name):
#    # '/hello/james' -> {"hello": "james"}
#    return {'hello': name}
#
# @app.route('/users', methods=['POST'])
# def create_user():
#     # This is the JSON body the user sent in their POST request.
#     user_as_json = app.json_body
#     # Suppose we had some 'db' object that we used to
#     # read/write from our database.
#     # user_id = db.create_user(user_as_json)
#     return {'user_id': user_id}
#
# See the README documentation for more examples.
#
